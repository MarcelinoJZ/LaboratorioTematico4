import android.content.Context
import android.content.SharedPreferences

class PreferencesManager private constructor(context: Context) {

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        PREF_FILE_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREF_FILE_NAME = "MyPreferences"
        private const val KEY_CORREO = "correo"
        private const val KEY_CONTRASEÑA = "contraseña"
        private const val KEY_NOMBRE = "nombre"
        private const val KEY_APELLIDO = "apellido"
        private const val KEY_FECHA = "feha"

        private const val KEY_SEXO = "sexo"
        private const val KEY_HOROSCOPO ="horoscopo"
        private const val KEY_HOBBIT = "hobbit"



        private const val KEY_RUTA_IMAGEN_PERFIL = "ruta_imagen_perfil"
        private const val KEY_IMAGEN_1 = "imagen_1"
        private const val KEY_IMAGEN_2 = "imagen_2"
        private const val KEY_IMAGEN_3 = "imagen_3"
        private const val KEY_IMAGEN_4 = "imagen_4"


        private var instance: PreferencesManager? = null

        fun getInstance(context: Context): PreferencesManager {
            if (instance == null) {
                instance = PreferencesManager(context)
            }
            return instance as PreferencesManager
        }
    }

    fun guardarComplemento(sexo: String, horoscopo: String, hobbit: String){
        val editor = sharedPreferences.edit()
        editor.putString(KEY_SEXO, sexo)
        editor.putString(KEY_HOROSCOPO, horoscopo)
        editor.putString(KEY_HOBBIT, hobbit)
        editor.apply()
    }

    fun obtenerSexo(): String {
        return sharedPreferences.getString(KEY_SEXO, "") ?: ""
    }
    fun obtenerHoroscopo(): String {
        return sharedPreferences.getString(KEY_HOROSCOPO, "") ?: ""
    }
    fun obtenerHobbit(): String {
        return sharedPreferences.getString(KEY_HOBBIT, "") ?: ""
    }


    fun guardarCredenciales(correo: String, contraseña: String, nombre: String, apellido:String, fecha: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_CORREO, correo)
        editor.putString(KEY_CONTRASEÑA, contraseña)
        editor.putString(KEY_NOMBRE, nombre)
        editor.putString(KEY_APELLIDO, apellido)
        editor.putString(KEY_FECHA, fecha)
        editor.apply()
    }

    fun obtenerCorreo(): String {
        return sharedPreferences.getString(KEY_CORREO, "") ?: ""
    }

    fun obtenerContraseña(): String {
        return sharedPreferences.getString(KEY_CONTRASEÑA, "") ?: ""
    }

    fun obtenerNombre(): String {
        return sharedPreferences.getString(KEY_NOMBRE, "") ?: ""
    }

    fun obtenerApellido(): String {
        return sharedPreferences.getString(KEY_APELLIDO, "") ?: ""
    }

    fun obtenerFecha(): String {
        return sharedPreferences.getString(KEY_FECHA, "") ?: ""
    }



    fun guardarRutaImagenPerfil(rutaImagen: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_RUTA_IMAGEN_PERFIL, rutaImagen)
        editor.apply()
    }

    fun obtenerRutaImagenPerfil(): String {
        return sharedPreferences.getString(KEY_RUTA_IMAGEN_PERFIL, "") ?: ""
    }

    fun borrarDatos() {
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }


    fun guardarImagen1(rutaImagen: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_IMAGEN_1, rutaImagen)
        editor.apply()
    }

    fun obtenerImagen1(): String {
        return sharedPreferences.getString(KEY_IMAGEN_1, "") ?: ""
    }

    fun guardarImagen2(rutaImagen: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_IMAGEN_2, rutaImagen)
        editor.apply()
    }

    fun obtenerImagen2(): String {
        return sharedPreferences.getString(KEY_IMAGEN_2, "") ?: ""
    }

    fun guardarImagen3(rutaImagen: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_IMAGEN_3, rutaImagen)
        editor.apply()
    }

    fun obtenerImagen3(): String {
        return sharedPreferences.getString(KEY_IMAGEN_3, "") ?: ""
    }

    fun guardarImagen4(rutaImagen: String) {
        val editor = sharedPreferences.edit()
        editor.putString(KEY_IMAGEN_4, rutaImagen)
        editor.apply()
    }

    fun obtenerImagen4(): String {
        return sharedPreferences.getString(KEY_IMAGEN_4, "") ?: ""
    }

}
