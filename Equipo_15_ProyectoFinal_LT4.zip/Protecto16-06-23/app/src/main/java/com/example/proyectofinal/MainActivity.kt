package com.example.proyectofinal

import PreferencesManager
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import com.example.proyectofinal.databinding.ActivityMainBinding
import com.example.proyectofinal.databinding.ComplementBinding
import com.example.proyectofinal.databinding.EditBinding
import com.example.proyectofinal.databinding.InformationBinding
import com.example.proyectofinal.databinding.LoginBinding
import com.example.proyectofinal.databinding.ProfileBinding
import com.example.proyectofinal.databinding.SingupBinding
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bindingLogin: LoginBinding
    private lateinit var bindingSingup: SingupBinding
    private lateinit var bindingProfile: ProfileBinding
    private lateinit var bindingInformation: InformationBinding
    private lateinit var bindingEdit: EditBinding
    private lateinit var bindingComplement : ComplementBinding

    private lateinit var currentView: View
    private lateinit var detectorDeGestos: GestureDetectorCompat

    private lateinit var preferencesManager: PreferencesManager

    private val imageDirectoryName = "profile_images"

    private var isUserLoggedIn = false

    // Arreglo de colores claros
    private val colors = arrayOf(
        Color.parseColor("#D3FF7C"), // Color claro 1
        Color.parseColor("#7CFFD7"), // Color claro 2
        Color.parseColor("#FFAAAA"), // Color claro 3
        Color.parseColor("#FFFFFF")  //color original
    )

    // Variable para realizar un seguimiento del índice del color actual
    private var currentColorIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        bindingLogin = LoginBinding.inflate(layoutInflater)
        bindingSingup = SingupBinding.inflate(layoutInflater)
        bindingProfile = ProfileBinding.inflate(layoutInflater)
        bindingInformation = InformationBinding.inflate(layoutInflater)
        bindingEdit = EditBinding.inflate(layoutInflater)
        bindingComplement = ComplementBinding.inflate(layoutInflater)


        preferencesManager = PreferencesManager.getInstance(this)

        currentView = binding.root
        setContentView(currentView)
        detectorDeGestos = GestureDetectorCompat(this, GestureListener())
        cambiarPantallas()
        menu()
        gestionarRegistro()
        gestionarInicioSesion()
        desactivarElementos()
        activarElementos()
        viewPass()
        images()
    }

    /*Cambiar pantallas Deslizando*/ /*REVISAR NO FUNCIONA*/
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event != null) {
            detectorDeGestos.onTouchEvent(event)
        }
        return super.onTouchEvent(event)
    }

    inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onFling(evt1: MotionEvent, evt2: MotionEvent, velocidadX: Float, velocidadY: Float): Boolean {
            val sensibilidad = 10

            if (isUserLoggedIn) {
                if (currentView == bindingInformation.root && evt1.x - evt2.x > sensibilidad) {
                    // Deslizar a la izquierda desde bindingInformation, cambiar a bindingProfile
                    setContentView(bindingProfile.root)
                    currentView = bindingProfile.root
                    return true
                } else if (currentView == bindingProfile.root && evt2.x - evt1.x > sensibilidad) {
                    // Deslizar a la derecha desde bindingProfile, cambiar a bindingInformation
                    setContentView(bindingInformation.root)
                    currentView = bindingInformation.root
                    return true
                }
            }

            return false
        }
    }


    private fun cambiarPantallas() {
        binding.bMainLogin.setOnClickListener {
            setContentView(bindingLogin.root)
        }

        binding.bMainSingup.setOnClickListener {
            setContentView(bindingSingup.root)
        }

        bindingLogin.bLoginLogin.setOnClickListener {
            setContentView(bindingProfile.root)
            mostrarInformacion()
        }

        bindingLogin.bLoginSingup.setOnClickListener {
            setContentView(bindingSingup.root)
            bindingSingup.editTextSingupName.setText("")
            bindingSingup.editTextSingupLastName.setText("")
            bindingSingup.editTextSingupDate.setText("")
            bindingSingup.editTextSingupMail.setText("")
            bindingSingup.editTextSingupPass.setText("")

        }

        bindingSingup.bSingupLogin.setOnClickListener {
            setContentView(bindingLogin.root)
            bindingLogin.editTextLoginUser.setText("")
            bindingLogin.editTextLoginPass.setText("")
        }

        bindingSingup.bSingupSingup.setOnClickListener {
            setContentView(bindingComplement.root)
        }
        bindingSingup.editTextSingupDate.setOnClickListener {
            mostrarSelectorFecha()
        }

        bindingInformation.bInfoClose.setOnClickListener {
            setContentView(bindingLogin.root)
            bindingLogin.editTextLoginUser.setText("")
            bindingLogin.editTextLoginPass.setText("")
        }

        bindingInformation.bInfoEdit.setOnClickListener {
            setContentView(bindingEdit.root)
        }

        bindingInformation.bInformationReturn.setOnClickListener {
            setContentView(bindingProfile.root)
        }

        bindingEdit.imageEditReturn.setOnClickListener {
            setContentView(bindingProfile.root)
        }

        bindingEdit.bEditSave.setOnClickListener {
            gestionarCambioContrasena()
        }

        bindingEdit.bEditCancel.setOnClickListener {
            setContentView(bindingProfile.root)
        }

        // Configurar el OnClickListener para el botón de cambio de color
        bindingEdit.imageButtonColorPicker.setOnClickListener {
            // Cambiar el color de fondo del layout principal utilizando el siguiente color del arreglo
            bindingProfile.root.setBackgroundColor(colors[currentColorIndex])

            // Incrementar el índice del color actual
            currentColorIndex = (currentColorIndex + 1) % colors.size
        }

        bindingComplement.bCompleSave.setOnClickListener{
            setContentView(bindingProfile.root)
            bindingComplement.editTextCompleHobbit.setText("")
            bindingComplement.opcionesSexo.clearCheck()
            bindingComplement.spinnerComple.setSelection(0)
            mostrarInformacion()
        }
    }

    /*Guardando datos y comprobando informacion*/
    private fun gestionarRegistro() {
        bindingSingup.bSingupSingup.setOnClickListener {
            val mail = bindingSingup.editTextSingupMail.text.toString()
            val pass = bindingSingup.editTextSingupPass.text.toString()
            val name = bindingSingup.editTextSingupName.text.toString()
            val lastName = bindingSingup.editTextSingupLastName.text.toString()
            val date = bindingSingup.editTextSingupDate.text.toString()

            if (mail.isNotEmpty() && pass.isNotEmpty() && name.isNotEmpty() && lastName.isNotEmpty() && date.isNotEmpty()) {
                // Obtener la fecha actual
                val currentDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

                // Guardar los datos de registro en PreferencesManager
                preferencesManager.guardarCredenciales(mail, pass, name, lastName, date)

                // Establecer el nombre y el apellido en el TextView
                val fullName = "$name.$lastName"
                bindingInformation.textViewInfoName.text = fullName
                bindingProfile.textViewProfileDatos.text = fullName

                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()

                setContentView(bindingComplement.root)
            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        bindingComplement.bCompleSave.setOnClickListener {
            val selectedHoroscope = bindingComplement.spinnerComple.selectedItem.toString()
            val selectedGender = when (bindingComplement.opcionesSexo.checkedRadioButtonId) {
                bindingComplement.radioMasculino.id -> "Masculino"
                bindingComplement.radioFemenino.id -> "Femenino"
                else -> ""
            }
            val hobbit = bindingComplement.editTextCompleHobbit.text.toString()

            preferencesManager.guardarComplemento(selectedGender, selectedHoroscope, hobbit)



            if (selectedGender.isNotEmpty() && selectedHoroscope.isNotEmpty() && hobbit.isNotEmpty()) {
                preferencesManager.guardarComplemento(selectedGender, selectedHoroscope, hobbit)
                Toast.makeText(this, "Datos guardados correctamente", Toast.LENGTH_SHORT).show()

                val resultado = "Hobbit: $hobbit"
                bindingInformation.textViewComplHobbit.text = resultado
                val horoscopo = "Horoscopo: $selectedHoroscope"
                bindingInformation.textViewComplHoroscopo.text = horoscopo
                val sexo = "Hobbit: $selectedGender"
                bindingInformation.textViewComplSexo.text = sexo

                setContentView(bindingProfile.root)


            } else {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /*Para cargar os datos inmediatamente al iniciar la aplicaion de nuevo*/
    override fun onResume() {
        super.onResume()
        mostrarInformacion()
    }

    private fun mostrarInformacion() {
        val storedMail = preferencesManager.obtenerCorreo()
        val storedName = preferencesManager.obtenerNombre()
        val storedFecha = preferencesManager.obtenerFecha()
        val imagePath = preferencesManager.obtenerRutaImagenPerfil()
        val storedLastName = preferencesManager.obtenerApellido()

        val infoText = "Email: $storedMail"
        bindingInformation.textViewInfoEmail.text = infoText

        // Establecer el nombre y la fecha en los TextView
        val name = "Nombre: $storedName"
        bindingInformation.textViewInfoName.text = name

        val fullName = "$storedName.$storedLastName"
        bindingProfile.textViewProfileDatos.text = fullName

        val fecha = "Nacimiento: $storedFecha"
        bindingInformation.textViewInfoLastName.text = fecha

        val apellido = "Apellido: $storedLastName"
        bindingInformation.textViewInfoDate.text = apellido

        val storedSexo = preferencesManager.obtenerSexo()
        val storedHoroscopo = preferencesManager.obtenerHoroscopo()
        val storedHobbit = preferencesManager.obtenerHobbit()

        val sexo = "Sexo: $storedSexo"
        bindingInformation.textViewComplSexo.text = sexo

        val horoscopo = "Horoscopo: $storedHoroscopo"
        bindingInformation.textViewComplHoroscopo.text = horoscopo

        val hobbit = "Hobbit: $storedHobbit"
        bindingInformation.textViewComplHobbit.text = hobbit

// Cargar y mostrar la imagen de perfil
        if (imagePath.isNotEmpty()) {
            val imageFile = File(imagePath)
            if (imageFile.exists()) {
                val imageUri = Uri.fromFile(imageFile)
                bindingInformation.imageInfoProfile.setImageURI(imageUri)
                bindingProfile.imageViewProfileImage.setImageURI(imageUri)
            }
        }
    }

    private fun mostrarSelectorFecha() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            // Aquí puedes guardar la fecha seleccionada en tus preferencias o en otra variable
            val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
            bindingSingup.editTextSingupDate.setText(selectedDate)
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun gestionarInicioSesion() {
        bindingLogin.bLoginLogin.setOnClickListener {
            val mail = bindingLogin.editTextLoginUser.text.toString()
            val pass = bindingLogin.editTextLoginPass.text.toString()

            if (mail.isNotEmpty() && pass.isNotEmpty()) {
                val storedMail = preferencesManager.obtenerCorreo()
                val storedPass = preferencesManager.obtenerContraseña()

                if (mail == storedMail && pass == storedPass) {
                    setContentView(bindingProfile.root)
                } else {
                    mostrarMensaje("Credenciales incorrectas")
                }
            } else {
                mostrarMensaje("Por favor, completa todos los campos")
            }
        }
    }

    private fun gestionarCambioContrasena() {
        bindingEdit.bEditSave.setOnClickListener {
            val currentPass = bindingEdit.editTextEditPass.text.toString()
            val newPass = bindingEdit.editTextEditNewPass.text.toString()
            val confirmPass = bindingEdit.editTextEditConfirmPass.text.toString()

            val storedMail = preferencesManager.obtenerCorreo()
            val storedPass = preferencesManager.obtenerContraseña()
            val storedName = preferencesManager.obtenerNombre()
            val storedFecha = preferencesManager.obtenerFecha()
            val storedLastName = preferencesManager.obtenerApellido()

            // Realizar las validaciones necesarias
            if (currentPass.isNotEmpty() && newPass.isNotEmpty() && confirmPass.isNotEmpty()) {
                if (currentPass == storedPass) {
                    if (newPass == confirmPass) {
                        // Actualizar la contraseña en PreferencesManager
                        preferencesManager.guardarCredenciales(storedMail, newPass, storedName, storedLastName,storedFecha)

                        mostrarMensaje("Contraseña actualizada exitosamente")
                        setContentView(bindingProfile.root)
                    } else {
                        mostrarMensaje("La nueva contraseña y su confirmación no coinciden")
                    }
                } else {
                    mostrarMensaje("La contraseña actual es incorrecta")
                }
            } else {
                mostrarMensaje("Por favor, completa todos los campos")
            }
        }
    }

    /*Activando Elemntps de SingUp y Login*/
    private fun desactivarElementos(){

        /*Desabilitando los elemntos del Registro*/
        bindingSingup.editTextSingupLastName.isEnabled =false
        bindingSingup.editTextSingupDate.isEnabled= false
        bindingSingup.editTextSingupMail.isEnabled=false
        bindingSingup.editTextSingupPass.isEnabled=false
        bindingSingup.buttonSingupViewPass.isEnabled=false

        /*Desabilitando los elemntos de iniciar sesion*/
        bindingLogin.editTextLoginPass.isEnabled=false
        bindingLogin.loginPass.isEnabled=false

        /*Desabilitando los elemntos de Editar*/
        bindingEdit.editTextEditNewPass.isEnabled=false
        bindingEdit.editTextEditConfirmPass.isEnabled=false
        bindingEdit.editPass.isEnabled=false
        bindingEdit.editNewPass.isEnabled=false
        bindingEdit.editNewPassConfirm.isEnabled=false
    }

    private fun activarElementos() {

        /*Activando apellido*/
        bindingSingup.editTextSingupName.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupLastName.isEnabled = true
                } else {
                    bindingSingup.editTextSingupLastName.isEnabled = false
                    bindingSingup.editTextSingupDate.isEnabled = false
                    bindingSingup.editTextSingupMail.isEnabled = false
                    bindingSingup.editTextSingupPass.isEnabled = false
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupLastName.isEnabled = true
                } else {
                    bindingSingup.editTextSingupLastName.isEnabled = false
                    bindingSingup.editTextSingupDate.isEnabled = false
                    bindingSingup.editTextSingupMail.isEnabled = false
                    bindingSingup.editTextSingupPass.isEnabled = false
                }
            }
        })

        /*Activando Nacimiento*/
        bindingSingup.editTextSingupLastName.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true

                } else {
                    bindingSingup.editTextSingupMail.isEnabled = false
                    bindingSingup.editTextSingupPass.isEnabled = false
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true
                } else {
                    bindingSingup.editTextSingupMail.isEnabled = false
                    bindingSingup.editTextSingupPass.isEnabled = false
                }
            }
        })


        /*Activando Correo*/
        bindingSingup.editTextSingupDate.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true
                    bindingSingup.editTextSingupMail.isEnabled = true
                } else {
                    bindingSingup.editTextSingupPass.isEnabled = false
                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true
                    bindingSingup.editTextSingupMail.isEnabled = true
                } else {
                    bindingSingup.editTextSingupPass.isEnabled = false
                }
            }
        })

        /*Activando Pass*/
        bindingSingup.editTextSingupMail.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true
                    bindingSingup.editTextSingupMail.isEnabled = true
                    bindingSingup.editTextSingupPass.isEnabled = true
                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true) {
                    bindingSingup.editTextSingupName.isEnabled = true
                    bindingSingup.editTextSingupLastName.isEnabled = true
                    bindingSingup.editTextSingupDate.isEnabled = true
                    bindingSingup.editTextSingupMail.isEnabled = true
                    bindingSingup.editTextSingupPass.isEnabled = true
                    bindingSingup.buttonSingupViewPass.isEnabled = true
                }
            }
        })

        /*Activando Pass Login */
        bindingLogin.editTextLoginUser.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingLogin.editTextLoginPass.isEnabled = true
                    bindingLogin.loginPass.isEnabled = true
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true) bindingLogin.editTextLoginPass.isEnabled = true
            }
        })

        /*Activando elementos de editar*/

        /*Activando ver oculatr password y nueva contraseña */
        bindingEdit.editTextEditPass.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                }
                else{
                    bindingEdit.editPass.isEnabled = false
                    bindingEdit.editTextEditNewPass.isEnabled = false
                    bindingEdit.editNewPass.isEnabled=false
                    bindingEdit.editNewPassConfirm.isEnabled=false
                    bindingEdit.editNewPassConfirm.isEnabled=false
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true){
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                }
                else{
                    bindingEdit.editPass.isEnabled = false
                    bindingEdit.editTextEditNewPass.isEnabled = false
                    bindingEdit.editNewPass.isEnabled=false
                    bindingEdit.editNewPassConfirm.isEnabled=false
                    bindingEdit.editNewPassConfirm.isEnabled=false

                }
            }
        })
        /*Activando ver oculatr password y confrimar contraseña */
        bindingEdit.editTextEditNewPass.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                    bindingEdit.editTextEditConfirmPass.isEnabled = true
                    bindingEdit.editNewPass.isEnabled = true

                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true){
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                    bindingEdit.editTextEditConfirmPass.isEnabled = true
                    bindingEdit.editNewPass.isEnabled = true
                }
            }
        })
        /*Activando ver oculatr password y confrimar contraseña */
        bindingEdit.editTextEditConfirmPass.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                    bindingEdit.editTextEditConfirmPass.isEnabled = true
                    bindingEdit.editNewPass.isEnabled = true
                    bindingEdit.editNewPassConfirm.isEnabled = true

                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s?.isNotEmpty() == true){
                    bindingEdit.editTextEditNewPass.isEnabled = true
                    bindingEdit.editPass.isEnabled = true
                    bindingEdit.editTextEditConfirmPass.isEnabled = true
                    bindingEdit.editNewPass.isEnabled = true
                    bindingEdit.editNewPassConfirm.isEnabled = true
                }
            }
        })

    }


    /*Mostrar Mensje para eliminar cuenta desde el menu desplegable*/
    private fun mostrarMensaje(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }

    private fun menu() {
        bindingProfile.imageProfileMenu.setOnClickListener { clickedView ->
            val popupMenu = PopupMenu(this, clickedView)
            popupMenu.inflate(R.menu.menu)

            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.item->{
                        setContentView(bindingInformation.root)
                        mostrarInformacion()
                        true
                    }
                    R.id.item1 -> {
                        setContentView(bindingEdit.root)
                        true
                    }
                    R.id.item2 -> {
                        finish()
                        true
                    }
                    R.id.item3 -> {
                        showConfirmationDialog()
                        bindingComplement.editTextCompleHobbit.setText("")
                        bindingComplement.opcionesSexo.clearCheck()
                        bindingComplement.spinnerComple.setSelection(0)
                        true
                    }

                    else -> false
                }
            }

            popupMenu.show()
        }
    }

    /*Ver Ocultar Password*/
    private fun togglePasswordVisibility(editText: EditText, toggleButton: ImageButton) {
        val inputType = editText.inputType
        if (inputType == InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_CLASS_TEXT) {
            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            toggleButton.setImageResource(R.drawable.open_eye)
        } else {
            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            toggleButton.setImageResource(R.drawable.baseline_password_24)
        }
        // Mueve el cursor al final del texto
        editText.setSelection(editText.text.length)
    }

    private fun viewPass(){
        bindingSingup.buttonSingupViewPass.setOnClickListener {
            togglePasswordVisibility(bindingSingup.editTextSingupPass, bindingSingup.buttonSingupViewPass)
        }

        bindingLogin.loginPass.setOnClickListener {
            togglePasswordVisibility(bindingLogin.editTextLoginPass, bindingLogin.loginPass)
        }



        bindingEdit.editPass.setOnClickListener {
            togglePasswordVisibility(bindingEdit.editTextEditPass, bindingEdit.editPass)
        }

        bindingEdit.editNewPass.setOnClickListener {
            togglePasswordVisibility(bindingEdit.editTextEditNewPass, bindingEdit.editNewPass)
        }

        bindingEdit.editNewPassConfirm.setOnClickListener {
            togglePasswordVisibility(bindingEdit.editTextEditConfirmPass, bindingEdit.editNewPassConfirm)
        }

    }

    /*Subir Imagenes y guardar en la direccion para cargarlas cuando se inicia la app*/
    private fun images(){
        val imageDirectory = File(getExternalFilesDir(null), imageDirectoryName)
        if (!imageDirectory.exists()) {
            imageDirectory.mkdirs()
        }

        bindingComplement.imageComple.setOnClickListener {
            seleccionarImagenGaleria(bindingComplement.imageComple)
        }
        bindingProfile.imageViewProfileImage1.setOnClickListener {
            seleccionarImagenGaleria(bindingProfile.imageViewProfileImage1)
        }
        bindingProfile.imageViewProfileImage2.setOnClickListener {
            seleccionarImagenGaleria(bindingProfile.imageViewProfileImage2)
        }
        bindingProfile.imageViewProfileImage3.setOnClickListener {
            seleccionarImagenGaleria(bindingProfile.imageViewProfileImage3)
        }
        bindingProfile.imageViewProfileImage4.setOnClickListener {
            seleccionarImagenGaleria(bindingProfile.imageViewProfileImage4)
        }

        val imagePath = preferencesManager.obtenerRutaImagenPerfil()
        if (imagePath.isNotEmpty()) {
            val imageFile = File(imagePath)
            if (imageFile.exists()) {
                val imageUri = Uri.fromFile(imageFile)
                cargarImagenDesdeUri(imageUri, bindingComplement.imageComple)
            }
        }

        val imagePath1 = preferencesManager.obtenerImagen1()
        if (imagePath1.isNotEmpty()) {
            val imageFile1 = File(imagePath1)
            if (imageFile1.exists()) {
                val imageUri1 = Uri.fromFile(imageFile1)
                cargarImagenDesdeUri(imageUri1, bindingProfile.imageViewProfileImage1)
            }
        }

        val imagePath2 = preferencesManager.obtenerImagen2()
        if (imagePath2.isNotEmpty()) {
            val imageFile2 = File(imagePath2)
            if (imageFile2.exists()) {
                val imageUri2 = Uri.fromFile(imageFile2)
                cargarImagenDesdeUri(imageUri2, bindingProfile.imageViewProfileImage2)
            }
        }

        val imagePath3 = preferencesManager.obtenerImagen3()
        if (imagePath3.isNotEmpty()) {
            val imageFile3 = File(imagePath3)
            if (imageFile3.exists()) {
                val imageUri3 = Uri.fromFile(imageFile3)
                cargarImagenDesdeUri(imageUri3, bindingProfile.imageViewProfileImage3)
            }
        }

        val imagePath4 = preferencesManager.obtenerImagen4()
        if (imagePath4.isNotEmpty()) {
            val imageFile4 = File(imagePath4)
            if (imageFile4.exists()) {
                val imageUri4 = Uri.fromFile(imageFile4)
                cargarImagenDesdeUri(imageUri4, bindingProfile.imageViewProfileImage4)
            }
        }
        if (isUserLoggedIn) {
            setContentView(bindingProfile.root)
            currentView = bindingProfile.root
        } else {
            setContentView(bindingLogin.root)
            currentView = bindingLogin.root
        }

    }

    private fun seleccionarImagenGaleria(imageView: ImageView) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, imageView.id)
    }

    private fun cargarImagenDesdeUri(uri: Uri, imageView: ImageView) {
        imageView.setImageURI(uri)
    }

    private fun guardarImagenEnAlmacenamiento(imageUri: Uri): String {
        val imageDirectory = File(getExternalFilesDir(null), imageDirectoryName)
        if (!imageDirectory.exists()) {
            imageDirectory.mkdirs()
        }
        val imageFileName = "image_${System.currentTimeMillis()}.jpg"
        val imageFile = File(imageDirectory, imageFileName)

        try {
            val inputStream = contentResolver.openInputStream(imageUri)
            val outputStream = FileOutputStream(imageFile)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return imageFile.absolutePath
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null) {
            val imageUri = data.data
            if (imageUri != null) {
                when (requestCode) {
                    bindingComplement.imageComple.id -> {
                        bindingComplement.imageComple.setImageURI(imageUri)
                        val imagePath = guardarImagenEnAlmacenamiento(imageUri)
                        preferencesManager.guardarRutaImagenPerfil(imagePath)
                        // Imprimir la ruta de la imagen seleccionada
                        Log.d("MainActivity", "Ruta de la imagen perfil: $imagePath")
                    }
                    bindingProfile.imageViewProfileImage1.id -> {
                        bindingProfile.imageViewProfileImage1.setImageURI(imageUri)
                        val imagePath1 = guardarImagenEnAlmacenamiento(imageUri)
                        preferencesManager.guardarImagen1(imagePath1)
                        // Imprimir la ruta de la imagen seleccionada
                        Log.d("MainActivity", "Ruta de imagen 1: $imagePath1")
                    }
                    bindingProfile.imageViewProfileImage2.id -> {
                        bindingProfile.imageViewProfileImage2.setImageURI(imageUri)
                        val imagePath2 = guardarImagenEnAlmacenamiento(imageUri)
                        preferencesManager.guardarImagen2(imagePath2)
                        // Imprimir la ruta de la imagen seleccionada
                        Log.d("MainActivity", "Ruta de imagen 2: $imagePath2")
                    }
                    bindingProfile.imageViewProfileImage3.id -> {
                        bindingProfile.imageViewProfileImage3.setImageURI(imageUri)
                        val imagePath3 = guardarImagenEnAlmacenamiento(imageUri)
                        preferencesManager.guardarImagen3(imagePath3)
                        // Imprimir la ruta de la imagen seleccionada
                        Log.d("MainActivity", "Ruta de imagen 3: $imagePath3")
                    }
                    bindingProfile.imageViewProfileImage4.id -> {
                        bindingProfile.imageViewProfileImage4.setImageURI(imageUri)
                        val imagePath4 = guardarImagenEnAlmacenamiento(imageUri)
                        preferencesManager.guardarImagen4(imagePath4)
                        // Imprimir la ruta de la imagen seleccionada
                        Log.d("MainActivity", "Ruta de imagen 4: $imagePath4")
                    }
                }
            }
        }
    }

    /*Eliminar Cuenta*/
    private fun showConfirmationDialog() {
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Confirmación")
        alertDialogBuilder.setMessage("¿Desea eliminar su cuenta?")
        alertDialogBuilder.setPositiveButton("Continuar") { _, _ ->
            // Acción a tomar si el usuario selecciona "Continuar"
            bindingLogin.editTextLoginUser.setText("")
            bindingLogin.editTextLoginPass.setText("")
            eliminarCuenta()
            setContentView(bindingLogin.root)


        }
        alertDialogBuilder.setNegativeButton("Cancelar") { _, _ ->
            bindingProfile.root
            mostrarInformacion()
        }
        alertDialogBuilder.show()
    }

    private fun eliminarCuenta() {
        PreferencesManager.getInstance(this).borrarDatos()

        // Eliminar las imágenes guardadas
        val imagePath = preferencesManager.obtenerRutaImagenPerfil()
        eliminarImagenDesdeRuta(imagePath)

        val imagePath1 = preferencesManager.obtenerImagen1()
        eliminarImagenDesdeRuta(imagePath1)

        val imagePath2 = preferencesManager.obtenerImagen2()
        eliminarImagenDesdeRuta(imagePath2)

        val imagePath3 = preferencesManager.obtenerImagen3()
        eliminarImagenDesdeRuta(imagePath3)

        val imagePath4 = preferencesManager.obtenerImagen4()
        eliminarImagenDesdeRuta(imagePath4)
    }
    private fun eliminarImagenDesdeRuta(imagePath: String) {
        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
        }
    }
}
